package com.anz.SpringBootPractise.model;

import lombok.Data;

@Data
public class Response {
	
	private String status;
	private Object data;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	//Default Constructor.
	public Response()
	{
		
	}
	
	//Parameterized Constructor.
	public Response(String status,Object data)
	{
		this.status=status;
		this.data=data;
	}
	
}
